import React from 'react'
import "./style/footer.css"

export default function Footer() {
  return (
    <div className='footer'>
        <h1>Created by_Osman</h1>
    </div>
  )
}
